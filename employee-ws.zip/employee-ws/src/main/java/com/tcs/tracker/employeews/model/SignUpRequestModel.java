package com.tcs.tracker.employeews.model;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;


public class SignUpRequestModel {

	@NotNull(message="Employee id field can not be left empty")
	//@Pattern(regexp="^/d*",message="Employee id consists of only digits")
	private String empId;
	
	@NotNull(message="Name field can not be left empty")
	@Pattern(regexp="^[a-zA-Z ]*",message="Please provide valid name")
	private String empName;
	
	@Past
	private LocalDate date_of_birth;
	
	@NotNull(message="Contact number can't be left empty")
	@Pattern(regexp="^[0-9]{10}",message="Please provide only 10 digits")
	private String contact;
	
	private String alt_contact;
	
	@NotNull(message="Please provide the valid role")
	private String role;
	
	@NotNull(message="Required field")
	private String securityQuestion;
	
	@Email(message="Please provide correct email id")
	private String email;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String emp_id) {
		this.empId = emp_id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmp_name(String emp_name) {
		this.empName = emp_name;
	}

	public LocalDate getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(LocalDate date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAlt_contact() {
		return alt_contact;
	}

	public void setAlt_contact(String alt_contact) {
		this.alt_contact = alt_contact;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
