package com.tcs.tracker.employeews.DAO;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepo extends CrudRepository<UserEntity, String> {

	public UserEntity findByEmpId(String empId);
	public List<UserEntity> findAllByFlag(Boolean userExists);
}
