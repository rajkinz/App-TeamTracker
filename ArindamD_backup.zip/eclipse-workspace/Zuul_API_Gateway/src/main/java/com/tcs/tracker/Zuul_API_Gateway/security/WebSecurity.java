package com.tcs.tracker.Zuul_API_Gateway.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

@Configuration
@EnableWebSecurity
public class WebSecurity extends WebSecurityConfigurerAdapter {

	@Autowired
	private Environment env;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable();
		http.headers().frameOptions().disable();
		
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		http.authorizeRequests().antMatchers(HttpMethod.POST,env.getProperty("login.url.endpoint")).permitAll()
								.antMatchers(HttpMethod.POST,env.getProperty("signup.url.endpoint")).permitAll()
								.antMatchers(env.getProperty("changePassword.url.endpoint")).permitAll()
								.antMatchers(env.getProperty("resetPassword.url.endpoint")).permitAll()
								.antMatchers("/employee-ws/h2-console").permitAll()
								.anyRequest().authenticated()
								.and().addFilter(new AuthorizationFilter(authenticationManager(), env));
	}

	
}
