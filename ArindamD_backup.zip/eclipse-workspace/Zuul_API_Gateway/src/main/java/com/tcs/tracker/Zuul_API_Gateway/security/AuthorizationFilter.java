package com.tcs.tracker.Zuul_API_Gateway.security;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import io.jsonwebtoken.Jwts;

public class AuthorizationFilter extends BasicAuthenticationFilter {

	private Environment env;
	private Logger logger = LoggerFactory.getLogger(AuthorizationFilter.class);
	
	public AuthorizationFilter(AuthenticationManager authManager, Environment env) {
		
		super(authManager);
		this.env = env;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
																			throws IOException, ServletException {
		
		String authHeader = request.getHeader(env.getProperty("authorization.header.name"));
		
		if(authHeader==null || !authHeader.startsWith(env.getProperty("authorization.header.prefix"))) {
		
			logger.error("Authorization is null in header or bearer is missing in the prefix.");
			chain.doFilter(request, response);
			return;
		}
		
		UsernamePasswordAuthenticationToken authentication = getAuthentication(request);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		chain.doFilter(request, response);
	}

	private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
		String authHeader = request.getHeader(env.getProperty("authorization.header.name"));
		
		if(authHeader==null) {
			logger.error("Authorization is null in header. It is not carrying any JWT token");
			return null;
		}
		
		String token = authHeader.replace("Bearer","");
		String userId = Jwts.parser().setSigningKey(env.getProperty("token.secret"))
										.parseClaimsJws(token)
										.getBody().getSubject();
		if(userId==null) {
			logger.error("User id is null in token");
			return null;
		}
		return new UsernamePasswordAuthenticationToken(userId, null, new ArrayList<>());
	}
	
	

}
