package com.tcs.tracker.Zuul_API_Gateway.ExceptionHandling;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class AppExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value= {Exception.class})
	public ResponseEntity<CustomErrorResponse> handleAnyException(Exception exc) {
		CustomErrorResponse error = new CustomErrorResponse(LocalDateTime.now(),
									exc.getLocalizedMessage(),HttpStatus.BAD_REQUEST.value());
		
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
}
