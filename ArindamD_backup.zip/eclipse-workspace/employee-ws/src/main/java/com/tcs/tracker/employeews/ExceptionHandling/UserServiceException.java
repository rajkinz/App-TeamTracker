package com.tcs.tracker.employeews.ExceptionHandling;

public class UserServiceException extends RuntimeException {

	public UserServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public UserServiceException(String arg0) {
		super(arg0);
	}

	public UserServiceException(Throwable arg0) {
		super(arg0);
	}
	
	
}
