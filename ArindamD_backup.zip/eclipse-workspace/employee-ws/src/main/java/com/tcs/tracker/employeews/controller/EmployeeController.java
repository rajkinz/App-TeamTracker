package com.tcs.tracker.employeews.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.tracker.employeews.DAO.UserEntity;
import com.tcs.tracker.employeews.ExceptionHandling.UserServiceException;
import com.tcs.tracker.employeews.model.ChangePasswordRequestModel;
import com.tcs.tracker.employeews.model.EmployeeResponseModel;
import com.tcs.tracker.employeews.model.LoginRequestModel;
import com.tcs.tracker.employeews.model.ResetPasswordRequestModel;
import com.tcs.tracker.employeews.model.SignUpRequestModel;
import com.tcs.tracker.employeews.service.EmployeeService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	private Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	@Autowired
	private EmployeeService employeeService;

	@Autowired
	BCryptPasswordEncoder bcrypt;

	@Autowired
	private Environment env;

	@PostMapping
	public ResponseEntity<?> signupEmployee(@Valid @RequestBody SignUpRequestModel signUp) {

		UserEntity user = employeeService.getUserById(signUp.getEmpId());
		if(user != null) throw new UserServiceException("Employee already exists");
		UserEntity userEntity = employeeService.createUser(signUp);

		return new ResponseEntity<>(userEntity, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteEmployee(@PathVariable String id, @RequestHeader(value="Authorization") String authHeader) {

		String token = authHeader.replace("Bearer","");
		String requestFromId = Jwts.parser().setSigningKey(env.getProperty("token.secret"))
											.parseClaimsJws(token).getBody().getSubject();
		
		UserEntity user = employeeService.getUserById(requestFromId);
		if(user.getRole().equals("user")) {
			logger.info(user.getEmpName() + " having employee id " +user.getEmpId() +" was trying to delete a user with id "+id);
			throw new UserServiceException("You dont have privileges to delete a user");
		}

		UserEntity userEntity = employeeService.getUserById(id);
		if(userEntity == null) throw new UserServiceException("Employee doesn't exist");
		if(!userEntity.getFlag()) throw new UserServiceException("Employee has already been deleted");
		

		employeeService.deleteUser(userEntity);
		return new ResponseEntity<>("Employee with id "+id+" has been deleted successfully !!", HttpStatus.OK);
	}
	
	@GetMapping
	public List<EmployeeResponseModel> getAllEmployees(@RequestHeader(value="Authorization") String authHeader) {
		String token = authHeader.replace("Bearer","");
		String requestFromId = Jwts.parser().setSigningKey(env.getProperty("token.secret"))
											.parseClaimsJws(token).getBody().getSubject();
		
		UserEntity user = employeeService.getUserById(requestFromId);
		if(user.getRole()=="user") throw new UserServiceException("You dont have privileges for this operation");
		
		boolean userExists = true;
		List<EmployeeResponseModel> employeeResponse = employeeService.getAllEmployees(userExists);
		return employeeResponse;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getEmployeeById(@PathVariable String id) {
		UserEntity userEntity = employeeService.getUserById(id);
		if (userEntity == null) throw new UserServiceException("Employee Doesn't Exist");
		if (!userEntity.getFlag()) throw new UserServiceException("Employee was deleted");
		ModelMapper modelMapper = new ModelMapper();
		return new ResponseEntity<>(modelMapper.map(userEntity, EmployeeResponseModel.class),HttpStatus.OK);
	}

	
	@PostMapping("/authenticate")
	public ResponseEntity<?> authenticateEmployee(@RequestBody LoginRequestModel login, HttpServletRequest req,
			HttpServletResponse res) {

		UserEntity userEntity = employeeService.getUserById(login.getEmpId());

		if (userEntity == null)
			throw new UserServiceException("Employee doesn't exist. Please sign-up to login.");
		
		if (!userEntity.getFlag())
			throw new UserServiceException("Employee was deleted");

		if (!bcrypt.matches(login.getPassword(), userEntity.getPassword()))
			throw new UserServiceException("Password is wrong. Incase if you have forgotten password please click on forgot password");

		String token = Jwts.builder().setSubject(userEntity.getEmpId())
				.setExpiration(
						new Date(System.currentTimeMillis() + Long.parseLong(env.getProperty("token.expiration.time"))))
				.signWith(SignatureAlgorithm.HS512, env.getProperty("token.secret")).compact();
		logger.info(userEntity.getEmpName() + " having employee id " +userEntity.getEmpId() +" has logged in ");
		res.addHeader("token", token);
		res.addHeader("role", userEntity.getRole());
		return new ResponseEntity<>("Authentication Successfull", HttpStatus.ACCEPTED);
	}

	@PutMapping("/changePassword")
	public ResponseEntity<?> changeUserPassword(@RequestBody ChangePasswordRequestModel changePwd,
												@RequestParam(value="empId") String empId) {

		UserEntity userEntity = employeeService.getUserById(empId);
		if (userEntity == null) throw new UserServiceException("Please provide correct employee id");
		
		if (changePwd.getNewPassword().equals(changePwd.getConfirmNewPassword())) {
			userEntity.setPassword(bcrypt.encode(changePwd.getNewPassword()));
			employeeService.updatePassword(userEntity);
			return new ResponseEntity<>("Password has been updated successfully for user " + empId, HttpStatus.CREATED);
		} else throw new UserServiceException("Passwords in both fields are not matching");
	}

	@PutMapping("/resetPassword")
	public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequestModel resetPassword,
											@RequestParam(value="empId") String empId) {

		UserEntity userEntity = employeeService.getUserById(empId);
		if(resetPassword.getSecurityQuestion().equals(userEntity.getSecurityQuestion())) {
			if(resetPassword.getNewPassword().equals(resetPassword.getConfirmNewPassword())) {
				userEntity.setPassword(bcrypt.encode(resetPassword.getNewPassword()));
				employeeService.updatePassword(userEntity);
				return new ResponseEntity<>("Password has been updated successfully for user "+empId,HttpStatus.CREATED);
			}
			else throw new UserServiceException("Both passwords are not matching");
		}
		else throw new UserServiceException("Security question is wrong");
			
	}

}
