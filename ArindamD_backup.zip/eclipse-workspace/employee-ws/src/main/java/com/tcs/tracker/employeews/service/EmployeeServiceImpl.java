package com.tcs.tracker.employeews.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.tcs.tracker.employeews.DAO.EmployeeRepo;
import com.tcs.tracker.employeews.DAO.UserEntity;
import com.tcs.tracker.employeews.model.EmployeeResponseModel;
import com.tcs.tracker.employeews.model.SignUpRequestModel;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired
	private BCryptPasswordEncoder bcrypt;
	
	public UserEntity createUser(SignUpRequestModel signUp) {
		ModelMapper modelMapper = new ModelMapper();
		UserEntity userEntity = modelMapper.map(signUp,UserEntity.class);
		
		
		LocalDate dob = signUp.getDate_of_birth();
		String dd = (dob.getDayOfMonth() < 10)?"0"+String.valueOf(dob.getDayOfMonth()):String.valueOf(dob.getDayOfMonth());
		String mm = (dob.getMonthValue() < 10)?"0"+String.valueOf(dob.getMonthValue()):String.valueOf(dob.getMonthValue());
		String defaultPassword = "Change@"+dd + mm + dob.getYear();
		
		userEntity.setPassword(bcrypt.encode(defaultPassword));
		userEntity.setFlag(true);
		employeeRepo.save(userEntity);
		
		return userEntity;
	}

	@Override
	public UserEntity getUserById(String id) {
		UserEntity userEntity = employeeRepo.findByEmpId(id);
		return userEntity;
	}

	@Override
	public void updatePassword(UserEntity userEntity) {

		employeeRepo.save(userEntity);
	}

	@Override
	public void deleteUser(UserEntity userEntity) {
		userEntity.setFlag(false);
		employeeRepo.save(userEntity);
		
	}

	@Override
	public List<EmployeeResponseModel> getAllEmployees(Boolean userExists) {
		ArrayList<UserEntity> userEntity = (ArrayList<UserEntity>) employeeRepo.findAllByFlag(userExists);
		List<EmployeeResponseModel> employeeResponse = new ArrayList<>();
		ModelMapper modelMapper = new ModelMapper();
		userEntity.stream().forEach(i->employeeResponse.add(modelMapper.map(i,EmployeeResponseModel.class)));
		
		return employeeResponse;
	}

}
