package com.tcs.tracker.employeews.service;

import java.util.List;

import com.tcs.tracker.employeews.DAO.UserEntity;
import com.tcs.tracker.employeews.model.EmployeeResponseModel;
import com.tcs.tracker.employeews.model.SignUpRequestModel;

public interface EmployeeService {

	public UserEntity createUser(SignUpRequestModel signUp);
	public UserEntity getUserById(String id);
	public void updatePassword(UserEntity userEntity);
	public void deleteUser(UserEntity userEntity);
	public List<EmployeeResponseModel> getAllEmployees(Boolean userExists);
	
}