package com.tcs.tracker.loginws.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.tracker.loginws.entity.UserEntity;
import com.tcs.tracker.loginws.model.LoginRequestModel;
import com.tcs.tracker.loginws.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class AuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	@Autowired
	private UserService userService;
	
	@Autowired
	private Environment env;
	
	private LoginRequestModel creds;
	
	@Override
	public Authentication attemptAuthentication(HttpServletRequest req, HttpServletResponse res) throws AuthenticationException {
		try {
			creds = new ObjectMapper().readValue(req.getInputStream(), LoginRequestModel.class);
			
			return getAuthenticationManager().authenticate(new UsernamePasswordAuthenticationToken(creds.getEmpId(),
																					creds.getPassword(),new ArrayList<>()));
		}
		catch(IOException exc) {
			throw new RuntimeException(exc);
		}
	}
	
	protected void successfulAuthentication(HttpServletRequest req, HttpServletResponse res,
											FilterChain chain, Authentication auth) throws IOException, ServletException {
		//String username = ((User) auth.getPrincipal()).getUsername();
		//UserEntity userEntity = userService.getUserDetailsbyId(creds.getEmpId());
		
		//Creating JWT token
		String token = Jwts.builder().setSubject(creds.getEmpId())
									 .setExpiration(new Date(System.currentTimeMillis()+Long.parseLong(env.getProperty("token.expiration.time"))))
									 .signWith(SignatureAlgorithm.HS512, env.getProperty("token.secret")).compact();
		
		res.addHeader("token", token);
		res.addHeader("empId", creds.getEmpId());
		//res.addHeader("role", userEntity.getRole());
		
		
	}
}
