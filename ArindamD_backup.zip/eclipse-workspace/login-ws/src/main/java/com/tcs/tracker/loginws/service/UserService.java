package com.tcs.tracker.loginws.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.tcs.tracker.loginws.entity.UserEntity;
import com.tcs.tracker.loginws.model.SignUpRequestModel;

public interface UserService extends UserDetailsService {

	public UserEntity createUser(SignUpRequestModel signup);
	public UserEntity getUserDetailsbyId(String emp_id);
}
