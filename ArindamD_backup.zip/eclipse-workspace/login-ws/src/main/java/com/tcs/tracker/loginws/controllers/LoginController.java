package com.tcs.tracker.loginws.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.tracker.loginws.entity.UserEntity;
import com.tcs.tracker.loginws.model.SignUpRequestModel;
import com.tcs.tracker.loginws.service.UserService;

@RestController
public class LoginController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/sign-up")
	public ResponseEntity<?> singUpUser(@Valid @RequestBody SignUpRequestModel signUp) {
		
		UserEntity userEntity = userService.createUser(signUp);
		
		return new ResponseEntity<>(userEntity,HttpStatus.OK);
		
	}
	
	@RequestMapping("/check/{id}")
	public UserEntity helloUser(@PathVariable String id) {
		return userService.getUserDetailsbyId(id);
	}
}
