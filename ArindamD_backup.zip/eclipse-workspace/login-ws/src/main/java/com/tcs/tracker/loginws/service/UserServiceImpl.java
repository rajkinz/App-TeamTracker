package com.tcs.tracker.loginws.service;

import java.time.LocalDate;
import java.util.ArrayList;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.tcs.tracker.loginws.DAO.UsersRepository;
import com.tcs.tracker.loginws.entity.UserEntity;
import com.tcs.tracker.loginws.model.SignUpRequestModel;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UsersRepository usersRepo;
	
	@Autowired
	private BCryptPasswordEncoder encryptPassword;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserEntity userEntity = usersRepo.findByEmpId(username);
		if(userEntity==null) throw new UsernameNotFoundException(username);
		
		return new User(userEntity.getEmpId(),userEntity.getPassword(),true,true,true,true,new ArrayList<>());
	}

	@Override
	public UserEntity createUser(SignUpRequestModel signUp) {

		ModelMapper modelMapper = new ModelMapper();
		UserEntity userEntity = modelMapper.map(signUp, UserEntity.class);
		LocalDate dob = signUp.getDate_of_birth();
		String dd = (dob.getDayOfMonth() < 10)?"0"+String.valueOf(dob.getDayOfMonth()):String.valueOf(dob.getDayOfMonth());
		String mm = (dob.getMonthValue() < 10)?"0"+String.valueOf(dob.getMonthValue()):String.valueOf(dob.getMonthValue());
		String defaultPassword = "Change@"+dd + mm + dob.getYear();
										  
				
		//userEntity.setPassword(defaultPassword);
		userEntity.setPassword(encryptPassword.encode(defaultPassword));
		usersRepo.save(userEntity);
		return userEntity;
	}

	@Override
	public UserEntity getUserDetailsbyId(String empId) {

		UserEntity userEntity= usersRepo.findByEmpId(empId);
		return userEntity;
	}

}
