package com.tcs.tracker.loginws.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.tcs.tracker.loginws.service.UserService;

@Configuration
@EnableWebSecurity
public class WebSecurity extends WebSecurityConfigurerAdapter {

	@Autowired
	private Environment env;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder bCrypt;
	
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/**").permitAll()
                .and().addFilter(getAuthenticationFilter());

        http.csrf().disable();
        http.headers().frameOptions().disable();
    }
    
    private AuthenticationFilter getAuthenticationFilter() throws Exception {
    	
    	AuthenticationFilter authFilter = new AuthenticationFilter();
    	authFilter.setAuthenticationManager(authenticationManager());
    	//authFilter.setFilterProcessesUrl(env.getProperty("login.url.path")); //if we need to change default /login endpoint for authentication
    	return authFilter;
    }
    
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	
    	auth.userDetailsService(userService).passwordEncoder(bCrypt);
    }
}

