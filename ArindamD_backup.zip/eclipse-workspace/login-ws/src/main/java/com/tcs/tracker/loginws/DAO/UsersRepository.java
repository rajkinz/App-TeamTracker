package com.tcs.tracker.loginws.DAO;


import org.springframework.data.repository.CrudRepository;

import com.tcs.tracker.loginws.entity.UserEntity;

public interface UsersRepository extends CrudRepository<UserEntity, Integer> {

	public UserEntity findByEmpId(String emp_id);
}
