# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:36:06 2020

@author: TensorFlow
"""

from flask import Flask,request,make_response
from sqlalchemy import create_engine
from logging import FileHandler, WARNING
import pandas as pd
import numpy as np
from re import search

app=Flask(__name__)

if not app.debug:
    file_handler = FileHandler("report-processing.log")
    file_handler.setLevel(WARNING)
    app.logger.addHandler(file_handler)

@app.route("/selected",methods=['GET'])
def profileProcessing():
    try:
        engine=create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/profile_evaluation')
        connection=engine.connect()
        skills_df=pd.read_sql_table("required_skills",connection)
        profiles_df=pd.read_sql_table("profiles",connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
        
    excel_file = request.files['file']
    xls = pd.ExcelFile(excel_file)
    newprofiles_df = pd.read_excel(xls,sheet_name='First Screening')
    empId=profiles_df['Emp_#_'].values.tolist()
    new_df=newprofiles_df[np.logical_not(newprofiles_df['Emp # '].isin(empId))]
    #if new_df.shape[0]==0:
    #    return "No new profiles"
    selected_dict={}
    rejected_dict={}
    for index1,rows1 in profiles_df.iterrows():
        flag=0
        for index,rows in skills_df.iterrows():
            skills=skills_df.loc[index,'Technology'].split(",")
            for skill in skills:
                if search(skill,str(profiles_df.loc[index1,'Skill_set_'])):
                    selected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_'],skills_df.iloc[index,2:].values]    
                    flag=1
            if flag==1: 
                break
        if flag==0:
            rejected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_']]
    
    ##### Selected profiles dataframe #####
    
    selected_df=pd.DataFrame(columns=['Employee_Number','Employee_Name','Skills_Set',"Bangalore_AssignedDM","Kochi_AssignedDM","Chennai_AssignedDM"])
    empnum=[]
    empname=[]
    skillsset=[]
    bngdm=[]
    kchdm=[]
    chdm=[]
    for key,value in selected_dict.items():
        empnum.append(key)
        empname.append(value[0])
        skillsset.append(value[1])
        bngdm.append(value[2][0])
        kchdm.append(value[2][1])
        chdm.append(value[2][2])
    selected_df['Employee_Number']=empnum
    selected_df['Employee_Name']=empname
    selected_df['Skills_Set']=skillsset
    selected_df['Bangalore_AssignedDM']=bngdm
    selected_df['Kochi_AssignedDM']=kchdm
    selected_df['Chennai_AssignedDM']=chdm

    ### Creating a response to send csv files as attachment ###
    res = make_response(selected_df.to_csv(index=False))
    res.headers["Content-Disposition"] = "attachment; filename=filtered_profiles.csv"
    res.headers["Content-Type"] = "text/csv"
    return res

152972,154813,160798,166757,167632
@app.route("/rejected",methods=['GET'])
def profileProcessing():
    try:
        engine=create_engine('mysql://teamtracker:teamtracker@13.235.199.150:3306/profile_evaluation')
        connection=engine.connect()
        skills_df=pd.read_sql_table("required_skills",connection)
        profiles_df=pd.read_sql_table("profiles",connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
        
    excel_file = request.files['file']
    xls = pd.ExcelFile(excel_file)
    newprofiles_df = pd.read_excel(xls,sheet_name='First Screening')
    empId=profiles_df['Emp_#_'].values.tolist()
    new_df=newprofiles_df[np.logical_not(newprofiles_df['Emp # '].isin(empId))]
    #if new_df.shape[0]==0:
    #    return "No new profiles"
    selected_dict={}
    rejected_dict={}
    for index1,rows1 in profiles_df.iterrows():
        flag=0
        for index,rows in skills_df.iterrows():
            skills=skills_df.loc[index,'Technology'].split(",")
            for skill in skills:
                if search(skill,str(profiles_df.loc[index1,'Skill_set_'])):
                    selected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_'],skills_df.iloc[index,2:].values]    
                    flag=1
            if flag==1: 
                break
        if flag==0:
            rejected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_']]
    

    
    #### Rejected Profiles dataframe
    
    rejected_df=pd.DataFrame(columns=['Employee_Number','Employee_Name','Skills_Set'])
    empnum=[]
    empname=[]
    skillsset=[]
    for key,value in rejected_dict.items():
        empnum.append(key)
        empname.append(value[0])
        skillsset.append(value[1])
    rejected_df['Employee_Number']=empnum
    rejected_df['Employee_Name']=empname
    rejected_df['Skills_Set']=skillsset

    ### Creating a response to send csv files as attachment ###
    res = make_response(rejected_df.to_csv(index=False))
    res.headers["Content-Disposition"] = "attachment; filename=rejected_profiles.csv"
    res.headers["Content-Type"] = "text/csv"
    return res


if __name__=="__main__":
    app.run(debug=True)