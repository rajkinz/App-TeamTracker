# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:36:06 2020

@author: TensorFlow
"""

from flask import Flask,request,make_response
from sqlalchemy import create_engine
from logging import FileHandler, WARNING
import pandas as pd
import numpy as np
from re import search,IGNORECASE

app=Flask(__name__)

if not app.debug:
    file_handler = FileHandler("report-processing.log")
    file_handler.setLevel(WARNING)
    app.logger.addHandler(file_handler)

@app.route("/selected",methods=['GET'])
def selectedprofileProcessing():
    try:
        engine=create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/profile_evaluation')
        connection=engine.connect()
        skills_df=pd.read_sql_table("required_skills",connection)
        existing_profiles_df=pd.read_sql_table("profiles",connection)
    except Exception as ex:
        app.logger.error(ex)
    #finally:
    #    connection.close()
        
    excel_file = request.files['file']
    xls = pd.ExcelFile(excel_file)
    profiles_df = pd.read_excel(xls)
    profiles_df.drop_duplicates(subset=profiles_df.columns[1],keep='first',inplace=True)
    cols=profiles_df.columns.tolist()
    colss=[s.replace(" ","_") for s in cols]
    profiles_df=profiles_df.rename(columns=dict(zip(cols,colss)))
    empId=existing_profiles_df['Emp_#_'].values.tolist()
    profiles_df=profiles_df[np.logical_not(profiles_df['Emp_#_'].isin(empId))]
    if profiles_df.shape[0]==0:
        return "No new profiles"
    
    #profiles_df=profiles_df.drop(columns=['S.No.'])
    #profiles_df.to_sql(name=profiles,con=connection,index=False,if_exists='append')
    selected_dict={}
    rejected_dict={}
    for index1,rows1 in profiles_df.iterrows():
        flag=0
        for index,rows in skills_df.iterrows():
            skills=skills_df.loc[index,'Technology'].split(",")
            for skill in skills:
                if search(skill,str(profiles_df.loc[index1,'Skill_set_']),IGNORECASE):
                    selected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_'],profiles_df.loc[index1,'Contact_Number'],profiles_df.loc[index1,'Years_of_Exp.'],profiles_df.loc[index1,'Base_Branch'],skills_df.iloc[index,2:].values]    
                    flag=1
            if flag==1: 
                break
        if flag==0:
            rejected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_'],profiles_df.loc[index1,'Contact_Number']]
    
    ##### Selected profiles dataframe #####
    
    selected_df=pd.DataFrame(columns=['Employee_Number','Employee_Name','Skills_Set',"Contact_Number","Years_of_Exp.","Base_Branch","Bangalore_AssignedDM","Kochi_AssignedDM","Chennai_AssignedDM"])
    empnum=[]
    empname=[]
    skillsset=[]
    mob=[]
    yxp=[]
    bsbr=[]
    bngdm=[]
    kchdm=[]
    chdm=[]
    for key,value in selected_dict.items():
        empnum.append(key)
        empname.append(value[0])
        skillsset.append(value[1])
        mob.append(value[2])
        yxp.append(value[3])
        bsbr.append(value[4])
        bngdm.append(value[5][0])
        kchdm.append(value[5][1])
        chdm.append(value[5][2])
    selected_df['Employee_Number']=empnum
    selected_df['Employee_Name']=empname
    selected_df['Skills_Set']=skillsset
    selected_df['Contact_Number']=mob
    selected_df['Years_of_Exp.']=yxp
    selected_df['Base_Branch']=bsbr
    selected_df['Bangalore_AssignedDM']=bngdm
    selected_df['Kochi_AssignedDM']=kchdm
    selected_df['Chennai_AssignedDM']=chdm

    ### Creating a response to send csv files as attachment ###
    res = make_response(selected_df.to_csv(index=False))
    res.headers["Content-Disposition"] = "attachment; filename=selected_profiles.csv"
    res.headers["Content-Type"] = "text/csv"
    return res


@app.route("/rejected",methods=['GET'])
def rejectedprofileProcessing():
    try:
        engine=create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/profile_evaluation')
        connection=engine.connect()
        skills_df=pd.read_sql_table("required_skills",connection)
        existing_profiles_df=pd.read_sql_table("profiles",connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
        
    excel_file = request.files['file']
    xls = pd.ExcelFile(excel_file)
    profiles_df = pd.read_excel(xls)
    profiles_df.drop_duplicates(subset=profiles_df.columns[1],keep='first',inplace=True)
    #profiles_df['Skill set ']=profiles_df['Skill set '].str.lower()
    cols=profiles_df.columns.tolist()
    colss=[s.replace(" ","_") for s in cols]
    profiles_df=profiles_df.rename(columns=dict(zip(cols,colss)))
    empId=existing_profiles_df['Emp_#_'].values.tolist()
    profiles_df=profiles_df[np.logical_not(profiles_df['Emp_#_'].isin(empId))]
    if profiles_df.shape[0]==0:
        return "No new profiles"
    
    #selected_dict={}
    rejected_dict={}
    for index1,rows1 in profiles_df.iterrows():
        flag=0
        for index,rows in skills_df.iterrows():
            skills=skills_df.loc[index,'Technology'].split(",")
            for skill in skills:
                if search(skill,str(profiles_df.loc[index1,'Skill_set_']),IGNORECASE):
                    #selected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_'],skills_df.iloc[index,2:].values]    
                    flag=1
            if flag==1: 
                break
        if flag==0:
            rejected_dict[profiles_df.loc[index1,'Emp_#_']]=[profiles_df.loc[index1,'Name'],profiles_df.loc[index1,'Skill_set_'],profiles_df.loc[index1,'Contact_Number']]
    

    
    #### Rejected Profiles dataframe
    
    rejected_df=pd.DataFrame(columns=['Employee_Number','Employee_Name','Skills_Set','Contact_Number'])
    empnum=[]
    empname=[]
    skillsset=[]
    mob=[]
    for key,value in rejected_dict.items():
        empnum.append(key)
        empname.append(value[0])
        skillsset.append(value[1])
        mob.append(value[2])
    rejected_df['Employee_Number']=empnum
    rejected_df['Employee_Name']=empname
    rejected_df['Skills_Set']=skillsset
    rejected_df['Contact_Number']=mob

    ### Creating a response to send csv files as attachment ###
    res = make_response(rejected_df.to_csv(index=False))
    res.headers["Content-Disposition"] = "attachment; filename=rejected_profiles.csv"
    res.headers["Content-Type"] = "text/csv"
    return res

@app.route("/duplicate",methods=['GET'])
def duplicateprofileProcessing():
    try:
        engine=create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/profile_evaluation')
        connection=engine.connect()
        skills_df=pd.read_sql_table("required_skills",connection)
        existing_profiles_df=pd.read_sql_table("profiles",connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
        
    excel_file = request.files['file']
    xls = pd.ExcelFile(excel_file)
    profiles_df = pd.read_excel(xls)
    profiles_df.drop_duplicates(subset=profiles_df.columns[1],keep='first',inplace=True)
    #profiles_df['Skill set ']=profiles_df['Skill set '].str.lower()
    cols=profiles_df.columns.tolist()
    colss=[s.replace(" ","_") for s in cols]
    profiles_df=profiles_df.rename(columns=dict(zip(cols,colss)))
    empId=existing_profiles_df['Emp_#_'].values.tolist()
    profiles_df=profiles_df[profiles_df['Emp_#_'].isin(empId)]
    
    res = make_response(profiles_df.to_csv(index=False))
    res.headers["Content-Disposition"] = "attachment; filename=duplicate_profiles.csv"
    res.headers["Content-Type"] = "text/csv"
    return res

if __name__=="__main__":
    app.run(debug=True)