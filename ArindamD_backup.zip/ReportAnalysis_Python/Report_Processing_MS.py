# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 19:38:23 2020

@author: TensorFlow
"""

from flask import Flask,jsonify,request
from sqlalchemy import create_engine
from logging import FileHandler, WARNING
import pandas as pd

app=Flask(__name__)

#app.config['MYSQL_HOST'] = 'localhost'
#app.config['MYSQL_USER'] = 'rajkinz'
#app.config['MYSQL_PASSWORD'] = 'raj54321'
#app.config['MYSQL_DB'] = 'report_processing'
#app.config['MYSQL_PORT']=3306

#mysql = MySQL(app)

if not app.debug:
    file_handler = FileHandler("report-processing.log")
    file_handler.setLevel(WARNING)
    app.logger.addHandler(file_handler)

@app.route("/upload",methods=['GET'])
def save_in_db():
    excel_file = request.files['file']
    xls = pd.ExcelFile(excel_file)
    trainings_df = pd.read_excel(xls,sheet_name='Mandatory Trainings')
    training_cols = trainings_df.columns.tolist()[11:-1]
    training_cols.insert(0,'Employee Number')
    tfactor_df=pd.read_excel(xls,sheet_name='T Factor')
    tfactor_milestone = pd.read_excel(xls,sheet_name='T Factor Milestone Challenge')
    milestone_status=dict(zip(tfactor_milestone['Employee id'].values,tfactor_milestone['status'].values))
    trainings_df1 = trainings_df[['Employee Number','Employee Name','BRM', 'DM','Completion status']]
    tfactor_df1 = pd.DataFrame(columns=["Employee Number","T-factor","Tfactor_Milestone_status"])
    tfactor_df1["Employee Number"] = tfactor_df['Employee #'].values
    tfactor_df1["T-factor"] = tfactor_df['T-factor'].values
    for index,rows in tfactor_df1.iterrows():
        id = tfactor_df1.loc[index,'Employee Number']
        if id in milestone_status.keys():
            tfactor_df1.loc[index,'Tfactor_Milestone_status']=milestone_status.get(id)
        else:
            tfactor_df1.loc[index,'Tfactor_Milestone_status']="Not Applicable"
    final_df = pd.merge(left=trainings_df1,right=tfactor_df1,how='outer',left_on='Employee Number', right_on='Employee Number')
    mandatory_trainings_df = trainings_df[training_cols]
    
    #Creating DB connectivity and directly saving dataframe to database
    sqlEngine = create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/report_processing')
    dbConnection = sqlEngine.connect()
    try:
        final_df.to_sql(con=dbConnection,name='status',if_exists='replace')
        mandatory_trainings_df.to_sql(con=dbConnection,name='mandatory_trainings',if_exists='replace')
    except Exception as ex:
        print(ex)
    finally:
        dbConnection.close()
    return "Report has been processed and saved successfully"

###############################################################################

@app.route("/defaulters", methods=['GET'])
def defaultersbyDM():
    manager = request.args.get('dm')
    try:
        sqlEngine = create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/report_processing')
        connection = sqlEngine.connect()
        status_df = pd.read_sql_table('status',connection)
        trainings_df = pd.read_sql_table('mandatory_trainings',connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
    if manager not in status_df['DM'].unique():
        return manager," is not desginated as delivery manager"
    status_df.drop(columns=['index'])
    trainings_df.drop(columns=['index'])
    training_names = trainings_df.columns.tolist()[1:]
    no_status = status_df['Completion status']=='N'
    no_status_df = status_df[no_status]
    df = pd.merge(left=no_status_df, right=trainings_df, how='inner',on='Employee Number')
    df['Employee Number'] = df['Employee Number'].apply(str)
    df_byDM = df.groupby(['DM'])
    if manager not in df_byDM.groups.keys():
        return "All associates under ",manager," are compliant to all the mandatory trainings"
    defaulters_byDM = {}
    for index in df_byDM.groups.get(manager):
        trainings=[]
        for name in training_names:
            if df.loc[index,name]=='N':
                trainings.append(name)
        defaulters_byDM[df.loc[index,'Employee Number']]=trainings
    return jsonify(defaulters_byDM)

###############################################################################

@app.route("/defaulters/<empId>",methods=['GET'])
def defaultersbyId(empId):
    try:
        sqlEngine = create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/report_processing')
        connection = sqlEngine.connect()
        status_df = pd.read_sql_table('status',connection)
        trainings_df = pd.read_sql_table('mandatory_trainings',connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
    if trainings_df[trainings_df['Employee Number']==int(empId)].shape[0]==0:
        return "Either provided employee id is wrong or it was not present in the report."
    index=status_df[status_df['Employee Number']==int(empId)].index.values[0]
    if status_df.loc[index,'Completion status']=='Y':
        return "The employee is fully compliant"
    else:
        training_names = trainings_df.columns.tolist()[2:]
        no_status = status_df['Completion status']=='N'
        no_status_df = status_df[no_status]
        df = pd.merge(left=no_status_df, right=trainings_df, how='inner',on='Employee Number')
        index=df[df['Employee Number']==int(empId)].index.values[0]
        trainings=[]
        for name in training_names:
            if df.loc[index,name]=='N':
                trainings.append(name)
        return jsonify(dict({empId:trainings}))
    
#################################################################################

@app.route("/tfactor",methods=['GET'])
def tfactorbyDM():
    manager = request.args.get('dm')
    try:
        sqlEngine = create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/report_processing')
        connection = sqlEngine.connect()
        status_df = pd.read_sql_table('status',connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
    if manager not in status_df['DM'].unique():
        return manager," is not desginated as delivery manager"
    df = status_df.groupby(['DM'])
    tfactor_byDM={}
    for index in df.groups.get(manager):
        tfactor=[]
        for name in ['T-factor','Tfactor_Milestone_status']:
            tfactor.append(status_df.loc[index,name])
        tfactor_byDM[str(status_df.loc[index,'Employee Number'])]=tfactor
    return jsonify(tfactor_byDM)

############################################################################

@app.route("/tfactor/<empId>",methods=['GET'])
def tfactorbyId(empId):
    try:
        sqlEngine = create_engine('mysql://rajkinz:raj54321@127.0.0.1:3306/report_processing')
        connection = sqlEngine.connect()
        status_df = pd.read_sql_table('status',connection)
        trainings_df = pd.read_sql_table('mandatory_trainings',connection)
    except Exception as ex:
        app.logger.error(ex)
    finally:
        connection.close()
    if trainings_df[trainings_df['Employee Number']==int(empId)].shape[0]==0:
        return "Either provided employee id is wrong or it was not present in the report."
    index=status_df[status_df['Employee Number']==int(empId)].index.values[0]
    tfactor={empId:[status_df.loc[index,'T-factor'],status_df.loc[index,'Tfactor_Milestone_status']]}
    return jsonify(tfactor)


if __name__=="__main__":
    app.run(debug=True)