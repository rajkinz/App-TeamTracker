from flask import Flask,jsonify,request
import json,requests

app = Flask(__name__)

@app.route("/get",methods=['GET'])
def testing():
    r = requests.get("http://127.0.0.1:5000/hello")
    data=r.json()
    print(data)
    return json.dumps(data)
if __name__=="__main__":
    app.run(debug=True, port=5001)