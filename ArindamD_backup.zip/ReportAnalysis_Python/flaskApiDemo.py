# -*- coding: utf-8 -*-
"""
Created on Sat Apr 18 22:10:38 2020

@author: TensorFlow
"""

from flask import Flask,jsonify,request
import pandas as pd

app=Flask(__name__)

@app.route("/defaulters", methods=['GET'])
def process_excel_sheet():
    excelFile = request.files['file']
    xls = pd.ExcelFile(excelFile)
    mandatoryTrainingSheet = pd.read_excel(xls,sheet_name="Mandatory Trainings")
    cols=mandatoryTrainingSheet.columns.tolist()
    mandatoryTrainingNames = cols[cols.index("Completion status")+1:-1]
    pendingDf=mandatoryTrainingSheet['Completion status']=='N'
    pendingmandatoryTrainingDf=mandatoryTrainingSheet[pendingDf]
    employeeDict = dict.fromkeys(pendingmandatoryTrainingDf['Employee Number'],[])
    for  index,row in pendingmandatoryTrainingDf.iterrows():
        value=[]
        for col in mandatoryTrainingNames:
            if row[col] == 'N':
                value.append(col)
        employeeDict[row['Employee Number']]=value
    return jsonify(employeeDict)

@app.route("/mandatoryTrainings/<id>", methods=['GET'])
def getpendingTrainings(id):
    excelFile = request.files['file']
    xls = pd.ExcelFile(excelFile)
    mandatoryTrainingSheet = pd.read_excel(xls,sheet_name="Mandatory Trainings")
    cols=mandatoryTrainingSheet.columns.tolist()
    mandatoryTrainingNames = cols[cols.index("Completion status")+1:-1]
    x=mandatoryTrainingSheet['Employee Number']==int(id)
    id_df=mandatoryTrainingSheet[x]
    if id_df['Completion status'].values[0]=='N':
        training=[]
        for s in mandatoryTrainingNames:
            if id_df[s].values[0] == 'N':
                training.append(s)
        trainings={969712:training}
        return jsonify(training);
    else:
        return "Fully compliant with mandatory trainings"

@app.route("/hello")
def hello():
    dic = {"tech":["AI","ML","Python"]}
    return jsonify(dic)
if __name__=="__main__":
    app.run(debug=True)